Python libraries required- tsfresh, pandas, numpy, matplotlib, sklearn, scipy.

Intructions-

1. Run main.py to get feature matrix before and after PCA.
2. For generating graphs, uncomment appropriate lines in the main file.